from flask import Flask, render_template

app = Flask(__name__)

@app.route('/')
def index():
    introduction = "Welcome to my 3D & Web Note!"
    contact_info = {"email": "eunjongdang@gmail.com", "phone": "010-8442-1577"}

    # 이미지 폴더 경로
    gallery_images = ["joinery_1.png", "joinery_1.png", "joinery_1.png"]
    app_list = ["App1", "App2", "App3"]

    return render_template('index.html', introduction=introduction, contact_info=contact_info, gallery_images=gallery_images, app_list=app_list)

if __name__=='__main__':
    app.run(debug=True)
    